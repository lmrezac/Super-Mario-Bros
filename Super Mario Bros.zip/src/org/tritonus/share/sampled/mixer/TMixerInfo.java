// 
// Decompiled by Procyon v0.5.29
// 

package org.tritonus.share.sampled.mixer;

import javax.sound.sampled.Mixer;

public class TMixerInfo extends Mixer.Info
{
    public TMixerInfo(final String a, final String b, final String c, final String d) {
        super(a, b, c, d);
    }
}
