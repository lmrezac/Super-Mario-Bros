// 
// Decompiled by Procyon v0.5.29
// 

package org.tritonus.share.sampled.mixer;

import javax.sound.sampled.CompoundControl;

public class TCompoundControlType extends CompoundControl.Type
{
    public TCompoundControlType(final String strName) {
        super(strName);
    }
}
