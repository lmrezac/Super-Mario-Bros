// 
// Decompiled by Procyon v0.5.29
// 

package org.tritonus.share;

public class GlobalInfo
{
    private static final String VENDOR = "Tritonus is free software. See http://www.tritonus.org/";
    private static final String VERSION = "0.3.1";
    
    public static String getVendor() {
        return "Tritonus is free software. See http://www.tritonus.org/";
    }
    
    public static String getVersion() {
        return "0.3.1";
    }
}
