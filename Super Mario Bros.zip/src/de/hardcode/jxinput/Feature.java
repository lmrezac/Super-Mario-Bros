// 
// Decompiled by Procyon v0.5.29
// 

package de.hardcode.jxinput;

public interface Feature
{
    String getName();
    
    boolean hasChanged();
}
