// 
// Decompiled by Procyon v0.5.29
// 

package de.hardcode.jxinput.event;

public interface JXInputAxisEventListener
{
    void changed(JXInputAxisEvent p0);
}
