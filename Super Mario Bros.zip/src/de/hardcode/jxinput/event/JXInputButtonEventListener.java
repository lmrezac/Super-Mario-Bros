// 
// Decompiled by Procyon v0.5.29
// 

package de.hardcode.jxinput.event;

public interface JXInputButtonEventListener
{
    void changed(JXInputButtonEvent p0);
}
