// 
// Decompiled by Procyon v0.5.29
// 

package de.hardcode.jxinput.event;

public interface JXInputDirectionalEventListener
{
    void changed(JXInputDirectionalEvent p0);
}
