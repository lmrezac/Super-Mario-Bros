// 
// Decompiled by Procyon v0.5.29
// 

package de.hardcode.jxinput.keyboard;

public class InvalidKeyCodeException extends IllegalArgumentException
{
    public InvalidKeyCodeException() {
    }
    
    public InvalidKeyCodeException(final String s) {
        super(s);
    }
}
