// 
// Decompiled by Procyon v0.5.29
// 

package de.hardcode.jxinput;

public interface Directional extends Feature
{
    boolean isCentered();
    
    int getDirection();
    
    double getValue();
    
    double getResolution();
}
