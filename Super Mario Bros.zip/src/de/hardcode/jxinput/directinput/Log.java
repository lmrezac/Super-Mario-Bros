// 
// Decompiled by Procyon v0.5.29
// 

package de.hardcode.jxinput.directinput;

import java.util.logging.Logger;

public class Log
{
    public static final Logger logger;
    
    static {
        logger = Logger.getLogger(Log.class.getPackage().getName());
    }
}
