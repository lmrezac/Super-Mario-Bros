// 
// Decompiled by Procyon v0.5.29
// 

package supermario.game.interfaces;

public class Constants
{
    public static double ENEMY_X_SPEED;
    public static double FRIEND_X_SPEED;
    public static double LAUNCHED_SHELL_X_SPEED;
    
    static {
        Constants.ENEMY_X_SPEED = 24.0;
        Constants.FRIEND_X_SPEED = 64.0;
        Constants.LAUNCHED_SHELL_X_SPEED = 200.0;
    }
}
