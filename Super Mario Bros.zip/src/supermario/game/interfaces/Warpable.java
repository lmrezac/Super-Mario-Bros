// 
// Decompiled by Procyon v0.5.29
// 

package supermario.game.interfaces;

import supermario.game.Warp;

public interface Warpable
{
    void setWarp(Warp p0);
}
