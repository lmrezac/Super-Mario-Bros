// 
// Decompiled by Procyon v0.5.29
// 

package supermario.game.interfaces;

public interface EnemyHolder
{
}
