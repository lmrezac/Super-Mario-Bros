// 
// Decompiled by Procyon v0.5.29
// 

package supermario.builder.itemPanels;

public interface ItemPanel
{
    void construct();
    
    void init();
    
    void refreshIcons();
}
