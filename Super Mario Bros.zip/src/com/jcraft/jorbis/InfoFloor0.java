// 
// Decompiled by Procyon v0.5.29
// 

package com.jcraft.jorbis;

class InfoFloor0
{
    int order;
    int rate;
    int barkmap;
    int ampbits;
    int ampdB;
    int numbooks;
    int[] books;
    
    InfoFloor0() {
        this.books = new int[16];
    }
}
