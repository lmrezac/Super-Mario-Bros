// 
// Decompiled by Procyon v0.5.29
// 

package com.jcraft.jorbis;

import com.jcraft.jogg.Buffer;

class Time0 extends FuncTime
{
    void pack(final Object o, final Buffer buffer) {
    }
    
    Object unpack(final Info info, final Buffer buffer) {
        return "";
    }
    
    Object look(final DspState dspState, final InfoMode infoMode, final Object o) {
        return "";
    }
    
    void free_info(final Object o) {
    }
    
    void free_look(final Object o) {
    }
    
    int forward(final Block block, final Object o) {
        return 0;
    }
    
    int inverse(final Block block, final Object o, final float[] array, final float[] array2) {
        return 0;
    }
}
