// 
// Decompiled by Procyon v0.5.29
// 

package com.jcraft.jorbis;

class LookResidue0
{
    InfoResidue0 info;
    int map;
    int parts;
    int stages;
    CodeBook[] fullbooks;
    CodeBook phrasebook;
    int[][] partbooks;
    int partvals;
    int[][] decodemap;
    int postbits;
    int phrasebits;
    int frames;
}
