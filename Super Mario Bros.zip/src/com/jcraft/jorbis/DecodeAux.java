// 
// Decompiled by Procyon v0.5.29
// 

package com.jcraft.jorbis;

class DecodeAux
{
    int[] tab;
    int[] tabl;
    int tabn;
    int[] ptr0;
    int[] ptr1;
    int aux;
}
