// 
// Decompiled by Procyon v0.5.29
// 

package com.jcraft.jorbis;

class AllocChain
{
    Object ptr;
    AllocChain next;
}
