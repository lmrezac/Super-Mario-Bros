// 
// Decompiled by Procyon v0.5.29
// 

package com.jcraft.jorbis;

class InfoMode
{
    int blockflag;
    int windowtype;
    int transformtype;
    int mapping;
}
