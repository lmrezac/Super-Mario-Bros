// 
// Decompiled by Procyon v0.5.29
// 

package com.jcraft.jorbis;

class EchstateFloor1
{
    int[] codewords;
    float[] curve;
    long frameno;
    long codes;
}
