// 
// Decompiled by Procyon v0.5.29
// 

package com.jcraft.jorbis;

class LookFloor0
{
    int n;
    int ln;
    int m;
    int[] linearmap;
    InfoFloor0 vi;
    Lpc lpclook;
    
    LookFloor0() {
        this.lpclook = new Lpc();
    }
}
