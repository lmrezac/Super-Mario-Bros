// 
// Decompiled by Procyon v0.5.29
// 

package com.jcraft.jorbis;

class LookMapping0
{
    InfoMode mode;
    InfoMapping0 map;
    Object[] time_look;
    Object[] floor_look;
    Object[] floor_state;
    Object[] residue_look;
    PsyLook[] psy_look;
    FuncTime[] time_func;
    FuncFloor[] floor_func;
    FuncResidue[] residue_func;
    int ch;
    float[][] decay;
    int lastframe;
}
