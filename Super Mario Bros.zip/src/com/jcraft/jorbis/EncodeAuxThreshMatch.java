// 
// Decompiled by Procyon v0.5.29
// 

package com.jcraft.jorbis;

class EncodeAuxThreshMatch
{
    float[] quantthresh;
    int[] quantmap;
    int quantvals;
    int threshvals;
}
