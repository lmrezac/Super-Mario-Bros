// 
// Decompiled by Procyon v0.5.29
// 

package com.jcraft.jorbis;

class EncodeAuxNearestMatch
{
    int[] ptr0;
    int[] ptr1;
    int[] p;
    int[] q;
    int aux;
    int alloc;
}
