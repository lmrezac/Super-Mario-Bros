// 
// Decompiled by Procyon v0.5.29
// 

package com.jcraft.jorbis;

class Lsfit_acc
{
    long x0;
    long x1;
    long xa;
    long ya;
    long x2a;
    long y2a;
    long xya;
    long n;
    long an;
    long un;
    long edgey0;
    long edgey1;
}
