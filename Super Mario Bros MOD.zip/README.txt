This is not a level. It is a MOD. The only one. This mod requires no installation, just extract the jar file and
run it like normal. 
Features:
- I added 2 new texture options: Super Mario Bros Special, and a custom one.
- I decrypted all the textures and most of the sounds, so you can change those now. 
	- Every tile texture can be animated. All you have to do is add new frames below the originals. 
	  The game will detect that the image is not square and will automatically load the animation.
	- The game uses special image files as palettes in order to save space. To make a palette, fill the top
	  row of pixels with 1 of every color in the original image, and then the bottom row with their replacements.
	- There is an optional custom water background file, in case the custom color file just doesn't cut it.
	  Look in the SMB Special texture files for what it is.
	- Don't try to make textures of different sizes than the originals like you would do with Minecraft. 
	  It won't work.
- There are 2 new cheat codes. 
	- What? You didn't know this game has cheat codes? Well, it does.
	  Enter them on the main menu by pressing arrow keys in certain configurations.
- The game is able to be converted to Super Luigi Bros thru use of a cheat code
	(Super Luigi Bros is exactly like Super Mario Bros, except mirrored from right to left)
- You can toggle playing as Luigi or Mario at the default main menu thru the use of another cheat code.


Why did I post this mod in the maps section of the site? Well, I originally had contacted Andrew Kellog about
posting it somewhere special on his site. I recieved two emails from him total, and sent him more than five.
He to this day still hasn't responded to my last two emails. So, that's why.